package top.jota.CRMJotaSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmJotaSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
